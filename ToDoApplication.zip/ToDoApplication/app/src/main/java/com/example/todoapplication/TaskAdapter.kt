package com.example.todoapplication

import android.app.Activity
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView

class TaskAdapter(
    private val context: Activity,
    private val tasks: ArrayList<String>

) : ArrayAdapter<String>(context, R.layout.task_item, tasks) {

    override fun getView(
        position: Int,
        convertView: View?,
        parent: ViewGroup
    ): View {

        // Tworzenie widoku pojedynczego elementu listy
        val inflater = LayoutInflater.from(context)

        val rowView = inflater.inflate(
            R.layout.task_item,
            null,
            true
        )

        // Pobranie TextView z XML
        val textViewTask =
            rowView.findViewById<TextView>(R.id.textViewTask)

        val textViewDate =
            rowView.findViewById<TextView>(R.id.textViewDate)

        // Pobranie zadania z listy
        val task = tasks[position]

        // Podział tekstu na linie
        val lines = task.split("\n")

        // Ustawienie tekstów
        textViewTask.text = lines[0]
        textViewDate.text = lines[1]

        // Kolory priorytetów
        when {

            // Wysoki = czerwony
            task.contains("[Wysoki]") -> {
                textViewTask.setTextColor(Color.RED)
            }

            // Średni = pomarańczowy
            task.contains("[Średni]") -> {
                textViewTask.setTextColor(
                    Color.rgb(255, 140, 0)
                )
            }

            // Niski = zielony
            task.contains("[Niski]") -> {
                textViewTask.setTextColor(Color.GREEN)
            }
        }

        return rowView
    }
}