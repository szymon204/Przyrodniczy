package com.example.todoapplication

import android.app.AlertDialog
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    // =========================
    // ELEMENTY INTERFEJSU
    // =========================

    // Pole wpisywania zadania
    private lateinit var poleZadania: EditText

    // Przycisk dodawania
    private lateinit var przyciskDodaj: Button

    // Lista zadań
    private lateinit var listaZadan: ListView

    // Licznik zadań
    private lateinit var tekstLicznik: TextView

    // Wybór priorytetu
    private lateinit var spinnerPriorytet: Spinner

    // Tekst gdy lista jest pusta
    private lateinit var tekstBrakZadan: TextView

    // =========================
    // DANE
    // =========================

    // Lista wszystkich zadań
    private lateinit var zadania: ArrayList<String>

    // Adapter ListView
    private lateinit var adapterZadan: TaskAdapter

    // Pamięć lokalna telefonu
    private lateinit var sharedPreferences: SharedPreferences

    // =========================
    // START APLIKACJI
    // =========================

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        // Połączenie z XML
        setContentView(R.layout.activity_main)

        // =========================
        // FINDVIEWBYID
        // =========================

        poleZadania =
            findViewById(R.id.editTextTask)

        przyciskDodaj =
            findViewById(R.id.buttonAdd)

        listaZadan =
            findViewById(R.id.listViewTasks)

        tekstLicznik =
            findViewById(R.id.textViewCounter)

        spinnerPriorytet =
            findViewById(R.id.spinnerPriority)

        tekstBrakZadan =
            findViewById(R.id.textViewEmpty)

        // =========================
        // SHAREDPREFERENCES
        // =========================

        sharedPreferences =
            getSharedPreferences(
                "TodoData",
                MODE_PRIVATE
            )

        // Wczytanie zapisanych danych
        wczytajZadania()

        // =========================
        // SPINNER PRIORYTETÓW
        // =========================

        val priorytety = arrayOf(
            "Niski",
            "Średni",
            "Wysoki"
        )

        val adapterSpinnera = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            priorytety
        )

        spinnerPriorytet.adapter = adapterSpinnera

        // =========================
        // ADAPTER LISTY
        // =========================

        adapterZadan =
            TaskAdapter(this, zadania)

        listaZadan.adapter = adapterZadan

        // Aktualizacja UI
        aktualizujLicznik()
        pokazLubUkryjPustyWidok()

        // =========================
        // DODAWANIE ZADANIA
        // =========================

        przyciskDodaj.setOnClickListener {

            // Tekst wpisany przez użytkownika
            val tekstZadania =
                poleZadania.text.toString()

            // Wybrany priorytet
            val wybranyPriorytet =
                spinnerPriorytet.selectedItem.toString()

            // Aktualna data
            val aktualnaData = SimpleDateFormat(
                "dd.MM.yyyy",
                Locale.getDefault()
            ).format(Date())

            // Sprawdzenie czy pole nie jest puste
            if (tekstZadania.isNotEmpty()) {

                // Ikona priorytetu
                val ikonaPriorytetu = when (wybranyPriorytet) {

                    "Wysoki" -> "🔴"

                    "Średni" -> "🟡"

                    else -> "🟢"
                }

                // Pełny tekst zadania
                val noweZadanie =
                    "$ikonaPriorytetu [$wybranyPriorytet] $tekstZadania\nDodano: $aktualnaData"

                // Dodanie zadania do listy
                zadania.add(noweZadanie)

                // Sortowanie
                sortujZadania()

                // Odświeżenie listy
                adapterZadan.notifyDataSetChanged()

                // Zapis danych
                zapiszZadania()

                // Aktualizacja UI
                aktualizujLicznik()
                pokazLubUkryjPustyWidok()

                // Wyczyszczenie pola
                poleZadania.text.clear()

                // Komunikat
                Toast.makeText(
                    this,
                    "Zadanie dodane",
                    Toast.LENGTH_SHORT
                ).show()

            } else {

                Toast.makeText(
                    this,
                    "Wpisz zadanie",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        // =========================
        // EDYCJA ZADANIA
        // =========================

        listaZadan.setOnItemClickListener {
                _, _, pozycja, _ ->

            // Wybrane zadanie
            val wybraneZadanie =
                zadania[pozycja]

            // Podział na linie
            val linie =
                wybraneZadanie.split("\n")

            // Pierwsza linia
            val pierwszaLinia =
                linie[0]

            // Usunięcie priorytetu z tekstu
            val samTekstZadania =
                pierwszaLinia
                    .replace("🔴 [Wysoki] ", "")
                    .replace("🟡 [Średni] ", "")
                    .replace("🟢 [Niski] ", "")

            // Pole edycji
            val poleEdycji =
                EditText(this)

            poleEdycji.setText(samTekstZadania)

            // Okno dialogowe
            AlertDialog.Builder(this)

                .setTitle("Edytuj zadanie")

                .setView(poleEdycji)

                .setPositiveButton("ZAPISZ") { _, _ ->

                    // Nowy tekst
                    val nowyTekst =
                        poleEdycji.text.toString()

                    // Stara data
                    val staraData =
                        linie[1]

                    // Zachowanie starego priorytetu
                    val zaktualizowaneZadanie = when {

                        wybraneZadanie.contains("[Wysoki]") ->

                            "🔴 [Wysoki] $nowyTekst\n$staraData"

                        wybraneZadanie.contains("[Średni]") ->

                            "🟡 [Średni] $nowyTekst\n$staraData"

                        else ->

                            "🟢 [Niski] $nowyTekst\n$staraData"
                    }

                    // Aktualizacja listy
                    zadania[pozycja] =
                        zaktualizowaneZadanie

                    // Sortowanie
                    sortujZadania()

                    // Odświeżenie
                    adapterZadan.notifyDataSetChanged()

                    // Zapis
                    zapiszZadania()

                    Toast.makeText(
                        this,
                        "Zadanie edytowane",
                        Toast.LENGTH_SHORT
                    ).show()
                }

                .setNegativeButton("ANULUJ", null)

                .show()
        }

        // =========================
        // USUWANIE ZADANIA
        // =========================

        listaZadan.setOnItemLongClickListener {
                _, _, pozycja, _ ->

            AlertDialog.Builder(this)

                .setTitle("Usuwanie")

                .setMessage(
                    "Czy usunąć zadanie?"
                )

                .setPositiveButton("TAK") { _, _ ->

                    // Usunięcie zadania
                    zadania.removeAt(pozycja)

                    // Sortowanie
                    sortujZadania()

                    // Odświeżenie
                    adapterZadan.notifyDataSetChanged()

                    // Zapis
                    zapiszZadania()

                    // Aktualizacja UI
                    aktualizujLicznik()
                    pokazLubUkryjPustyWidok()

                    Toast.makeText(
                        this,
                        "Zadanie usunięte",
                        Toast.LENGTH_SHORT
                    ).show()
                }

                .setNegativeButton("NIE", null)

                .show()

            true
        }
    }

    // =========================
    // ZAPIS DANYCH
    // =========================

    private fun zapiszZadania() {

        // Edytor pamięci
        val editor =
            sharedPreferences.edit()

        // Gson zamienia listę na JSON
        val gson = Gson()

        val json =
            gson.toJson(zadania)

        // Zapis danych
        editor.putString(
            "tasks",
            json
        )

        editor.apply()
    }

    // =========================
    // WCZYTYWANIE DANYCH
    // =========================

    private fun wczytajZadania() {

        val gson = Gson()

        // Pobranie danych
        val json =
            sharedPreferences.getString(
                "tasks",
                null
            )

        // Typ ArrayList<String>
        val typListy =
            object : TypeToken<ArrayList<String>>() {}.type

        // Sprawdzenie czy dane istnieją
        zadania = if (json != null) {

            gson.fromJson(
                json,
                typListy
            )

        } else {

            ArrayList()
        }
    }

    // =========================
    // LICZNIK ZADAŃ
    // =========================

    private fun aktualizujLicznik() {

        tekstLicznik.text =
            "Liczba zadań: ${zadania.size}"
    }

    // =========================
    // PUSTA LISTA
    // =========================

    private fun pokazLubUkryjPustyWidok() {

        if (zadania.isEmpty()) {

            tekstBrakZadan.visibility =
                TextView.VISIBLE

        } else {

            tekstBrakZadan.visibility =
                TextView.GONE
        }
    }

    // =========================
    // SORTOWANIE PRIORYTETÓW
    // =========================

    private fun sortujZadania() {

        zadania.sortBy {

            when {

                // Najwyższy priorytet
                it.contains("[Wysoki]") -> 1

                // Średni priorytet
                it.contains("[Średni]") -> 2

                // Niski priorytet
                else -> 3
            }
        }
    }
}